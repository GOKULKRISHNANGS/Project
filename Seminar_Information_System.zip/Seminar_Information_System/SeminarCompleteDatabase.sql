create table t_xbbnhgy_logindetails(userid varchar(30) primary key, password varchar(20), preference varchar(10));


create table t_xbbnhgy_student(studentid varchar(6) primary key, studentname varchar(30), stream varchar(10), userid varchar(30) references t_xbbnhgy_logindetails(userid));


create table t_xbbnhgy_professor(professorid varchar(6) primary key, professorname varchar(30), experience int,userid varchar(30) references t_xbbnhgy_logindetails(userid));



create table t_xbbnhgy_courses(courseid int primary key,coursename varchar(15),professorid varchar(6) references t_xbbnhgy_professor(professorid));



create table t_xbbnhgy_classroom(classroomid int primary key, location varchar(10), seats int);
insert into t_xbbnhgy_classroom values(5,'blocktwo',130);


create table t_xbbnhgy_coursecalender(courseid int primary key, classroomid int references t_xbbnhgy_classroom(classroomid), timefrom date, totime date);
insert into t_xbbnhgy_coursecalender values(1,2,'2017-08-08','2017-12-12');



create table t_xbbnhgy_administrator(name varchar(20), userid varchar(30) references t_xbbnhgy_logindetails(userid));


create table t_xbbnhgy_topics(topicname varchar(20) , periods int, courseid int references t_xbbnhgy_courses(courseid));


create table t_xbbnhgy_registry (studentid varchar(6) references t_xbbnhgy_student(studentid), courseid int references t_xbbnhgy_courses(courseid));
insert into t_xbbnhgy_registry values('xbb06', 6);
insert into t_xbbnhgy_registry values('xbb06', 2);

set schema courses;

delete from t_xbbnhgy_topics;

delete from t_xbbnhgy_courses where coursename = 'mICROCONTROLLER';

DELETE from t_xbbnhgy_coursecalender where courseid = 6;

delete from t_xbbnhgy_slogindetails where userid =  '"krish@gmail.com"';

delete from t_xbbnhgy_registry where studentid = 'xbb06';

drop table t_xbbnhgy_logindetails;
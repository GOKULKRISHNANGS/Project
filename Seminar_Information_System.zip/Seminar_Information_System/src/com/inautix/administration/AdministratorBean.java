package com.inautix.administration;

public class AdministratorBean {
	public int adminID;
	public String adminName;
	public String adminMailID;

	public int getAdminID() {
		return adminID;
	}

	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminMailID() {
		return adminMailID;
	}

	public void setAdminMailID(String adminMailID) {
		this.adminMailID = adminMailID;
	}
}

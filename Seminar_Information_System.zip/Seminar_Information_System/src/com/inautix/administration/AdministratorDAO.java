package com.inautix.administration;

public class AdministratorDAO {
	public void viewCourse(){
		
	}
	public void viewToics(){
		
	}
	public void viewClassRooms(){
		
	}
	public void viewCalender(){
		
	}
	public void manageProfessors(){
		
	}
	public void manageClassRooms(){
		
	}
}

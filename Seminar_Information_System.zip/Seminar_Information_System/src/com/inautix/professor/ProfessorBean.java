package com.inautix.professor;

public class ProfessorBean {
	private String professorID;
	private String professorName;
	private int experience;
	private String stream;
	private String professorMailID;

	public String getProfessorMailID() {
		return professorMailID;
	}

	public void setProfessorMailID(String professorMailID) {
		this.professorMailID = professorMailID;
	}

	public String getProfessorID() {
		return professorID;
	}

	public void setProfessorID(String professorID) {
		this.professorID = professorID;
	}

	public String getProfessorName() {
		return professorName;
	}

	public void setProfessorName(String professorName) {
		this.professorName = professorName;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}
}

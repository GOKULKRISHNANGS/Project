package com.inautix.servletcontainer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.coursecalender.CourseCalenderBean;
import com.inautix.coursecalender.CourseCalenderDAO;
import com.inautix.courses.CoursesBean;
import com.inautix.courses.CoursesDAO;

public class CreateCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CreateCourse() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		CoursesBean coursesbean = new CoursesBean();
		CourseCalenderBean calenderbean = new CourseCalenderBean();

		CourseCalenderDAO calenderdao = new CourseCalenderDAO();
		CoursesDAO coursesdao = new CoursesDAO();

		String courseName = request.getParameter("coursename");
		int courseID = Integer.valueOf(request.getParameter("courseid"));
		String professorID = request.getParameter("professorid");
		String classRoomID = request.getParameter("classroomid");
		Date fromTime = null;
		Date toTime = null;
		try {
			fromTime = calenderbean
					.formatDate(request.getParameter("fromtime"));
			toTime = calenderbean.formatDate(request.getParameter("totime"));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		coursesbean.setCourseName(courseName);
		coursesbean.setCourseID(courseID);
		coursesbean.setProfessorID(professorID);
		calenderbean.setCourseID(courseID);
		calenderbean.setFromTime(fromTime);
		calenderbean.setToTime(toTime);
		calenderbean.setClassRoomID(Integer.valueOf(classRoomID));

		int result = 0;

		try {
			result = coursesdao.createCourse(coursesbean);
			System.out.println("************************Update Courses**********************");
		} catch (SQLException e) {
			e.printStackTrace();
		}

			try {
				result = calenderdao.addCourseDetails(calenderbean);
				System.out.println("************************Updated Course Calender**********************");
			} catch (SQLException e) {
				e.printStackTrace();
			}

		if (result > 0) {
			//response.sendRedirect("/professormycourses.jsp");
			out.print("Successfully created new course");
		} else {
			RequestDispatcher rd = getServletContext().getRequestDispatcher(
					"/professormycourses.jsp");
			out.print("Invalid input");
			rd.include(request, response);
		}

	}

}

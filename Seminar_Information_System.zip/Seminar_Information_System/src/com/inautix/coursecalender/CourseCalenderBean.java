package com.inautix.coursecalender;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CourseCalenderBean {
	public int courseID;
	public int classRoomID;
	public Date fromTime;
	public Date toTime;
	
	public Date formatDate(String date) throws ParseException{
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd");
		Date formattedDate = sdf.parse(date);
		return formattedDate;
		
	}
	
	public int getCourseID() {
		return courseID;
	}
	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}
	public int getClassRoomID() {
		return classRoomID;
	}
	public void setClassRoomID(int classRoomID) {
		this.classRoomID = classRoomID;
	}
	public Date getFromTime() {
		return fromTime;
	}
	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}
	public Date getToTime() {
		return toTime;
	}
	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}
}

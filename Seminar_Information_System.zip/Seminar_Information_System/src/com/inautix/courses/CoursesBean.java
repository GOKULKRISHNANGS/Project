package com.inautix.courses;

import java.util.Date;

public class CoursesBean {
	private String courseName;
	private int courseID;
	private String professorID;
	public int classRoomID;
	public Date fromTime;
	public Date toTime;

	public int getClassRoomID() {
		return classRoomID;
	}

	public void setClassRoomID(int classRoomID) {
		this.classRoomID = classRoomID;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public CoursesBean() {

	}

	public CoursesBean(String courseName, int courseID,
			String courseInformation, String professorID2) {
		this.courseName = courseName;
		this.courseID = courseID;
		this.professorID = professorID2;
	}

	public String getProfessorID() {
		return professorID;
	}

	public void setProfessorID(String professorID) {
		this.professorID = professorID;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

}

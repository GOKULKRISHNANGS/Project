package com.inautix.DButil;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class supportClass {
	public static void main(String[] args) throws SQLException, IOException {
		Scanner ob = new Scanner(System.in);
		BufferedReader reader = new BufferedReader(
				new FileReader("topics.csv"));
		DBUtil db = new DBUtil();
		Connection con = null;
		String line = "";
		try {
			con = db.getDBConnection();
			if (con != null) {
				while((line = reader.readLine())!=null){
					String[] str = line.split("[,]");
					String query = "insert into t_xbbnhgy_topics values(?,?,?)";
					PreparedStatement stmt = con.prepareStatement(query);
					System.out.println();
					stmt.setString(1, str[0]);
					stmt.setInt(2, Integer.parseInt(str[1]));
					//stmt.setInt(3, Integer.valueOf(str[2]));
					stmt.setInt(3, Integer.parseInt(str[2]));

					int rs = stmt.executeUpdate();
					if (rs > 0) {
						System.out.println("Inserted Successfully");
					}
				} 
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
	}
}

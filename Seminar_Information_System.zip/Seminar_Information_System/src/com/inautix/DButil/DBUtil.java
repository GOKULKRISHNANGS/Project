package com.inautix.DButil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public Connection getDBConnection() throws ClassNotFoundException {
		Connection con = null;
		System.out.println("Establishing connection with database...");
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		try {
			con = DriverManager.getConnection("jdbc:derby://172.24.19.152:1527/Courses;create=true;user=Courses;password=pwd");
			System.out.println("Successfully connected...!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}

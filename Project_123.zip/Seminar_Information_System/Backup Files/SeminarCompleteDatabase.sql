create table t_xbbnhgy_logindetails(userid varchar(30) primary key, password varchar(20), preference varchar(10));
insert into t_xbbnhgy_logindetails values('admin@gmail.com', 'admin','admin');

create table t_xbbnhgy_student(studentid varchar(6) primary key, studentname varchar(30), stream varchar(10), userid varchar(30) references t_xbbnhgy_logindetails(userid));


create table t_xbbnhgy_professor(professorid varchar(6) primary key, professorname varchar(30), experience int,userid varchar(30) references t_xbbnhgy_logindetails(userid));



create table t_xbbnhgy_courses(courseid int primary key,coursename varchar(15),professorid varchar(6) references t_xbbnhgy_professor(professorid));



create table t_xbbnhgy_classroom(classroomid int primary key, location varchar(10), seats int);
insert into t_xbbnhgy_classroom values(5,'blocktwo',130);
drop table t_xbbnhgy_classroom;


create table t_xbbnhgy_coursecalender(courseid int primary key, classroomid int references t_xbbnhgy_classroom(classroomid), timefrom date, totime date);

alter table t_xbbnhgy_coursecalender drop column classroomid;


insert into t_xbbnhgy_coursecalender values(1,2,'2017-08-08','2017-12-12');



create table t_xbbnhgy_administrator(name varchar(20), userid varchar(30) references t_xbbnhgy_logindetails(userid));


create table t_xbbnhgy_topics(topicname varchar(20) , periods int, courseid int references t_xbbnhgy_courses(courseid));


create table t_xbbnhgy_registry (studentid varchar(6) references t_xbbnhgy_student(studentid), courseid int references t_xbbnhgy_courses(courseid));
insert into t_xbbnhgy_registry values('xbb06', 6);
insert into t_xbbnhgy_registry values('xbb06', 2);

set schema courses;

delete from t_xbbnhgy_topics;

select * from t_xbbnhgy_professor;

delete from t_xbbnhgy_courses where coursename = 'vlsi';

DELETE from t_xbbnhgy_coursecalender where courseid = 7;

delete from t_xbbnhgy_slogindetails where userid =  '"krish@gmail.com"';

delete from t_xbbnhgy_registry where courseid = 7;

truncate table t_xbbnhgy_courses;

drop table t_xbbnhgy_logindetails;
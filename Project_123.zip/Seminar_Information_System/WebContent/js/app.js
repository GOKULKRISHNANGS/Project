var app = angular.module("app", [ "ngRoute" ]);

app.config(function($routeProvider) {
	$routeProvider.when("/", {
		templateUrl : "js/home.html"
	}).when("/topic1", {
		templateUrl : "js/topic1.html"
	}).when("/topic2", {
		templateUrl : "js/topic2.html"
	}).when("/topic3", {
		templateUrl : "js/topic3.html"
	}).when("/topic4", {
		templateUrl : "js/topic4.html"
	}).when("/topic5", {
		templateUrl : "js/topic5.html"
	}).when("/topic6", {
		templateUrl : "js/topic6.html"
	}).when("/topic7", {
		templateUrl : "js/topic7.html"
	}).when("/topic8", {
		templateUrl : "js/topic8.html"
	});
});
package com.inautix.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.administration.AdministratorBean;
import com.inautix.administration.AdministratorDAO;

@RestController
@RequestMapping(value = "/stocks")
public class StockController {

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<AdministratorBean> getAllStocks() throws SQLException {
		
		AdministratorDAO stockdao = new AdministratorDAO();
		List<AdministratorBean> list = new ArrayList<>();
		list = stockdao.viewAccount();

		return list;
	}
	
	@RequestMapping(value = "/alll", method = RequestMethod.POST)
	public List<AdministratorBean> getAllStock() throws SQLException {
		
	

		return null;
	}
}
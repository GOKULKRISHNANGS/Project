package com.inautix.coursecalender;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.inautix.DButil.DBUtil;

public class CourseCalenderDAO {

	public String dateFormat(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = sdf.format(date);
		return formattedDate;
	}

	public int addCourseDetails(CourseCalenderBean bean) throws SQLException {
		DBUtil connect = new DBUtil();
		CourseCalenderDAO calender = new CourseCalenderDAO();
		Connection con = null;
		int result = 0;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "insert into t_xbbnhgy_coursecalender values(?,?,?)";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setInt(1, bean.getCourseID());
				stmt.setString(2, calender.dateFormat(bean.getFromTime()));
				stmt.setString(3, calender.dateFormat(bean.getToTime()));
				result = stmt.executeUpdate();
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return result;
	}

	public List viewCourseCalender() throws SQLException {
		DBUtil connect = new DBUtil();
		List<CourseCalenderBean> list = new ArrayList<>();
		CourseCalenderDAO calender = new CourseCalenderDAO();
		Connection con = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select * from t_xbbnhgy_coursecalender where";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setInt(1, 1);
				stmt.setInt(2, 1);
				stmt.setString(3, "");
				stmt.setString(4, "");
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return list;
	}
}

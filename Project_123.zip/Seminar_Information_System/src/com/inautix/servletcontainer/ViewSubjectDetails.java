package com.inautix.servletcontainer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.professor.ProfessorBean;
import com.inautix.professor.ProfessorDAO;

/**
 * Servlet implementation class ViewSubjectDetails
 */
public class ViewSubjectDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewSubjectDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String subjectName = request.getParameter("courseid");
			int subjectID = Integer.parseInt(request.getParameter("id"));
			request.setAttribute("subjectName", new String(subjectName+".txt"));
			ProfessorDAO professordao = new ProfessorDAO();
			ArrayList<ProfessorBean> arraylist = new ArrayList<ProfessorBean>();
			try {
				arraylist = professordao.getProfessorDetails(subjectID);
				request.setAttribute("details",arraylist);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			RequestDispatcher rd = request
					.getRequestDispatcher("subjectdetails.jsp");
			rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}

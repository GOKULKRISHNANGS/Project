package com.inautix.servletcontainer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.courses.CoursesBean;
import com.inautix.courses.CoursesDAO;
import com.inautix.student.StudentDAO;

public class EnrollCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EnrollCourse() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		if (session == null) {
			RequestDispatcher rd = request
					.getRequestDispatcher("LoginPage.html");
			rd.forward(request, response);
		} else {
			String userID = String.valueOf(session.getAttribute("name"));
			String courseId = String.valueOf(request.getParameter("courseid"));
			try {
				CoursesDAO coursesdao = new CoursesDAO();
				boolean b = coursesdao.applyCourse(userID, courseId);
				if (b == true) {
					RequestDispatcher rd = request
							.getRequestDispatcher("ViewMyCourses");
					rd.include(request, response);
				} else {
					RequestDispatcher rd = request
							.getRequestDispatcher("studentenrollcourse.jsp");
					out.print("You are already enrolled to this course");
					rd.include(request, response);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}

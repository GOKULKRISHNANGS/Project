package com.inautix.courses;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.inautix.DButil.DBUtil;

public class CoursesDAO implements iCourse {

	public String dateFormat(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = sdf.format(date);
		return formattedDate;
	}

	public static List<String> enrollStatus(String userID) throws SQLException {
		DBUtil connect = new DBUtil();
		ArrayList<String> arraylist = new ArrayList<String>();
		Connection con = null;
		String studentID = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select studentid from t_xbbnhgy_student where userid = ? ";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, userID);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					studentID = rs.getString(1);
				}
				stmt.close();
				query = "select coursename from t_xbbnhgy_courses natural join t_xbbnhgy_registry where studentid = ? ";
				stmt = con.prepareStatement(query);
				stmt.setString(1, studentID);
				rs = stmt.executeQuery();
				while (rs.next()) {
					arraylist.add(rs.getString(1));
				}
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return arraylist;
	}

	public List<CoursesBean> viewCourses(String userID) throws SQLException {
		List<CoursesBean> list = new ArrayList<CoursesBean>();
		CourseFunctions function = new CourseFunctions();
		DBUtil connect = new DBUtil();
		Connection con = null;
		List<String> statuslist = enrollStatus(userID);
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select * from t_xbbnhgy_courses";
				PreparedStatement stmt = con.prepareStatement(query);
				ResultSet rs = stmt.executeQuery();
				query = "select * from t_xbbnhgy_coursecalender";
				stmt = con.prepareStatement(query);
				ResultSet rs2 = stmt.executeQuery();
				while (rs.next() && rs2.next()) {
					CoursesBean bean = new CoursesBean();
					bean.setCourseName(rs.getString(2));
					bean.setCourseID(rs.getInt(1));
					bean.setProfessorID(rs.getString(3));
					bean.setFromTime(rs2.getDate(2));
					System.out.println(rs2.getDate(2)+"   "+rs2.getDate(3));
					bean.setToTime(rs2.getDate(3));
					list.add(bean);
				}
				for (CoursesBean bean : list) {
					if (statuslist.contains(bean.getCourseName())) {
						bean.setEnrollmentStatus(true);
					} else {
						bean.setEnrollmentStatus(false);
					}
				}
				
				list = function.decideUpdates(list);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return list;
	}

	public void viewCourseInformation() throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select coursename, courseinformation from t_xbbnhgy_courses";
				PreparedStatement stmt = con.prepareStatement(query);
				ResultSet rs = stmt.executeQuery();
				System.out.println("Viewing Couse Information");
				System.out
						.printf("%-20s %-20s /n", "CourseName", "Information");
				System.out.println("-----------------------------");
				while (rs.next()) {
					System.out.printf("%-20s %-20s /n", rs.getString(1),
							rs.getString(2));
				}
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
	}

	public int createCourse(CoursesBean coursesbean) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		int result = 0;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "insert into t_xbbnhgy_courses values(?,?,?)";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setInt(1, coursesbean.getCourseID());
				stmt.setString(2, coursesbean.getCourseName());
				stmt.setString(3, coursesbean.getProfessorID());
				result = stmt.executeUpdate();
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return result;
	}

	public void modifyCourse(String preface, String courseName) {
		try {
			FileWriter wr = new FileWriter(new File(
					"C:/Users/XBBNHGY/workspace/Seminar_Information_System/WebContent/TextFiles/"
							+ courseName + ".txt"));
			System.out.println(preface);// this line print user comments in
										// console
			wr.write(preface);
			wr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void removeCourse() {

	}

	public boolean applyCourse(String userID, String subID) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		boolean bool = false;
		int res = 0;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				System.out.println("Enrolling your name");
				String studentID = "";
				String query = "select studentid from t_xbbnhgy_student where userid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, userID);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					studentID = rs.getString(1);
				}
				query = "select count(*) from t_xbbnhgy_registry where studentid = ? and courseid = ? group by studentid";
				stmt = con.prepareStatement(query);
				stmt.setString(1, studentID);
				stmt.setString(2, subID);
				rs = stmt.executeQuery();
				while (rs.next()) {
					res = rs.getInt(1);
				}
				if (res < 1) {
					query = "insert into t_xbbnhgy_registry values(?,?)";
					stmt = con.prepareStatement(query);
					stmt.setString(1, studentID);
					stmt.setInt(2, Integer.valueOf(subID));
					int result = stmt.executeUpdate();
					if (result > 0) {
						bool = true;
						System.out
								.println("You have successfully enrolled for the course");
					}
				} else {
					bool = false;
					System.out.println("Enrollment not successful...");
				}
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return bool;

	}
}
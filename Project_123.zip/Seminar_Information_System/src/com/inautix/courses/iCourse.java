package com.inautix.courses;

import java.sql.SQLException;
import java.util.List;

import com.inautix.student.StudentBean;

public interface iCourse {

	public List<CoursesBean> viewCourses(String userID) throws SQLException;

	public void viewCourseInformation() throws SQLException;

	public int createCourse(CoursesBean coursesbean) throws SQLException;

	public void modifyCourse(String preface, String subjectName);

	public void removeCourse();

	public boolean applyCourse(String name, String subjectID) throws SQLException;

}

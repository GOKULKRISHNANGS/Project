package com.inautix.courses;

import java.util.Date;

public class CoursesBean {
	private String courseName;
	private int courseID;
	private String professorID;
	public int classRoomID;
	public Date fromTime;
	public Date toTime;
	public boolean enrollmentStatus;
	public int enrolledCount;
	public String timeCreated;

	public String getTimeCreated() {
		return timeCreated;
	}

	public void setTimeCreated(String timeCreated) {
		this.timeCreated = timeCreated;
	}

	public int getEnrolledCount() {
		return enrolledCount;
	}

	public void setEnrolledCount(int enrolledCount) {
		this.enrolledCount = enrolledCount;
	}

	public boolean getEnrollmentStatus() {
		return enrollmentStatus;
	}

	public void setEnrollmentStatus(boolean enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}

	public int getClassRoomID() {
		return classRoomID;
	}

	public void setClassRoomID(int classRoomID) {
		this.classRoomID = classRoomID;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public CoursesBean() {

	}

	public String getProfessorID() {
		return professorID;
	}

	public void setProfessorID(String professorID) {
		this.professorID = professorID;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

}

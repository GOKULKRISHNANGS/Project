package com.inautix.professor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inautix.DButil.DBUtil;
import com.inautix.courses.CoursesBean;

public class ProfessorDAO {
	public void createCourse() {

	}

	public void insertTopics() {

	}

	public void manageTopics() {

	}

	public void manageCreateCourseInformation() {
	}

	public List<CoursesBean> viewMyCourses(String userID) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		ArrayList<CoursesBean> list = new ArrayList<CoursesBean>();
		String profID = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select professorid from t_xbbnhgy_professor where userid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, userID);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					profID = rs.getString(1);
				}
				query = "select courseid, coursename from t_xbbnhgy_courses where professorid = ?";
				stmt = con.prepareStatement(query);
				stmt.setString(1, profID);
				rs = stmt.executeQuery();
				if (rs != null)
					while (rs.next()) {
						CoursesBean bean = new CoursesBean();
						bean.setCourseID(rs.getInt(1));
						bean.setCourseName(rs.getString(2));
						query = "select count(*) from t_xbbnhgy_registry where courseid = ? group by courseid";
						stmt = con.prepareStatement(query);
						stmt.setInt(1, rs.getInt(1));
						ResultSet rs1 = stmt.executeQuery();
						while (rs1.next()) {
							bean.setEnrolledCount(rs1.getInt(1));
						}
						list.add(bean);
					}
				else
					System.out.println(0);
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return list;
	}

	public void viewEnrollments(String profID) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select studentid from t_xbbnhgy_registry where courseid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, profID);
				ResultSet rs = stmt.executeQuery();
				if (rs != null)
					while (rs.next()) {
						System.out.println(rs.getString(1));
					}
				else
					System.out.println(0);
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
	}

	public ArrayList<ProfessorBean> getProfessorDetails(int courseID)
			throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		ArrayList<ProfessorBean> arraylist = new ArrayList<ProfessorBean>();
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select t_xbbnhgy_professor.professorid, t_xbbnhgy_professor.professorname, t_xbbnhgy_professor.experience,userid from t_xbbnhgy_professor natural join t_xbbnhgy_courses where courseid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setInt(1, courseID);
				ResultSet rs = stmt.executeQuery();
				if (rs != null)
					while (rs.next()) {
						ProfessorBean bean = new ProfessorBean();
						bean.setProfessorID(rs.getString(1));
						System.out.println(rs.getString(1));
						bean.setProfessorName(rs.getString(2));
						bean.setExperience(rs.getInt(3));
						bean.setProfessorMailID(rs.getString(4));
						arraylist.add(bean);
					}
				else
					System.out.println(0);

			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return arraylist;
	}

	public String getProfessorID(String userID) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		String professorID = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select professorid from t_xbbnhgy_professor natural join t_xbbnhgy_logindetails where userid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, userID);
				ResultSet rs = stmt.executeQuery();
				if (rs != null)
					while (rs.next()) {
						professorID = (rs.getString(1));
					}
				else
					System.out.println(0);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return professorID;
	}
}

package com.inautix.administration;

public class AdministratorBean {
	public String userID;
	public String password;
	public String preference;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String adminID) {
		this.userID = adminID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String adminName) {
		this.password = adminName;
	}

	public String getPreference() {
		return preference;
	}

	public void setPreference(String adminMailID) {
		this.preference = adminMailID;
	}
}

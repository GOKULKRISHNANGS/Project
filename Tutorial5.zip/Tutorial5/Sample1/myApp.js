var app=a ngular.module('myApp',[" ngRoute"]);

app.controller('navCtrl',['$scope','$location',function($scope,$location){

$scope.navLinks=[{
Title:'/',
LinkText:'Home',
},{
Title:'page1',
LinkText:'AboutUs'
},{
Title:'page2',
LinkText:'ContactUs'
}];

$scope.navClass=function(page){
varcurrentRoute=$location.path().substring(1)||'home';
returnpage===currentRoute?'active':'';
};

}]);

app.config(function($routeProvider){
	$routeProvider
	.when("/",{
		templateUrl:"home.html"
		
	}).when("/page1",{
		templateUrl:"page1.html"
	}).when("/page2",{
		templateUrl:"page2.html"
	});
});
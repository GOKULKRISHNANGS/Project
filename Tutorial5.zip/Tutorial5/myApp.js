var app=angular.module('app',[]);

app.controller('NavigationController',function($scope){
//Mustuseawrapperobject,otherwise"activeItem"won'twork
$scope.states={};
$scope.states.activeItem='item1';
$scope.items=[{
id:'item1',
title:'Home'
},{
id:'item2',
title:'PublicRooms'
},{
id:'item3',
title:'MyRooms'
}];
});